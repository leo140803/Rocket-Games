package com.mygdx.game;

import org.omg.CORBA.PUBLIC_MEMBER;

import java.awt.*;

public class StrongMeteor extends Obstacle{

    public StrongMeteor(Rectangle input){
        super(input,100);
    }
}
