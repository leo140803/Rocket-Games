package com.mygdx.game;


import com.badlogic.gdx.Game;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Meteor extends Game {
	public SpriteBatch batch;
	MainMenuScreen mainmenu;
	BitmapFont font;
	GameScreen gameScreen;
	TryAgainScreen againScreen;

	@Override
	public void create () {
		batch= new SpriteBatch();
		font= new BitmapFont();
		mainmenu= new MainMenuScreen(this);
		gameScreen= new GameScreen(this);
		againScreen= new TryAgainScreen(this,0);
		this.setScreen(mainmenu);
	}
	
	@Override
	public void dispose () {
		super.dispose();
		batch.dispose();
		font.dispose();
		mainmenu.dispose();
		gameScreen.dispose();
		againScreen.dispose();
	}
}
