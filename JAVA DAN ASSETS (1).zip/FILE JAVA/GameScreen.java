package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.TimeUtils;
import java.awt.*;

public class GameScreen implements Screen {
    Texture planeImg;
    Texture leftLaserImg;
    Texture rightLaserImg;
    Texture peluruPlaneImg;
    Texture blueNeonImg;
    Texture meteorImg;
    Texture meteor2Img;
    Texture backgrounImg;


    Rectangle plane;
    Rectangle leftNeon;
    Rectangle rightNeon;
    Array<Rectangle> peluruPlane;
    Array<Rectangle>blueNeon;
    Rectangle meteor;
    Rectangle background;

    Music planeMusic;
    Sound laserSound;
    Sound meteorDestroyedSound;
    Sound collisionWithLaserSound;
    Sound planeMeteor;

    OrthographicCamera camera;

    int index;
    long lastTime;
    int randomMeteor;
    int score;

    //Class sendiri
    Plane input;
    Obstacle obstacle;
    final Meteor game;

    public GameScreen(Meteor game){
        this.game=game;
        score=0;
        planeImg= new Texture(Gdx.files.internal("pesawat3.png"));
        leftLaserImg= new Texture(Gdx.files.internal("neonKiri.png"));
        rightLaserImg= new Texture(Gdx.files.internal("neonKanan.png"));
        peluruPlaneImg= new Texture(Gdx.files.internal("peluruRed.png"));
        blueNeonImg= new Texture(Gdx.files.internal("blueNeon.png"));
        meteorImg= new Texture(Gdx.files.internal("meteor.png"));
        meteor2Img= new Texture(Gdx.files.internal("meteorLemah.png"));
        backgrounImg= new Texture(Gdx.files.internal("bintang2.png"));

        planeMusic= Gdx.audio.newMusic(Gdx.files.internal("PlaneSound.wav"));
        planeMusic.setLooping(true);
        planeMusic.play();

        laserSound= Gdx.audio.newSound(Gdx.files.internal("laser.mp3"));
        meteorDestroyedSound= Gdx.audio.newSound(Gdx.files.internal("meteorDestroyed.wav"));
        collisionWithLaserSound= Gdx.audio.newSound(Gdx.files.internal("collisionWithLaser.mp3"));
        planeMeteor= Gdx.audio.newSound(Gdx.files.internal("planeMeteor.wav"));


        plane= new Rectangle();
        plane.x= 600/2-55/2;
        plane.y=70;
        plane.width=55;
        plane.height=55;

        leftNeon= new Rectangle();
        leftNeon.x=0;
        leftNeon.y=-60;
        leftNeon.width=64;
        leftNeon.height=700;

        rightNeon= new Rectangle();
        rightNeon.x=536;
        rightNeon.y=-60;
        rightNeon.width=64;
        rightNeon.height=700;

        background= new Rectangle();
        background.x=0;
        background.y=0;
        background.width=600;
        background.height=450;

        peluruPlane= new Array<>();
        createPeluru();

        meteor= new Rectangle();

        blueNeon= new Array<>();
        blueNeon.add(null);
        blueNeon.add(null);
        randomMeteor= MathUtils.random(0,1);
        spawnBlueNeonAndMeteor();

        if(randomMeteor==0){
            obstacle= new StrongMeteor(meteor);
        }else {
            obstacle= new WeakMeteor(meteor);
        }
        index=1;
        camera=new OrthographicCamera();
        camera.setToOrtho(false,600,450);

        //class sendiri
        input= new Plane(plane,150);



    }
    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0,0,0, 1);
        camera.update();
        game.batch.setProjectionMatrix(camera.combined);
        game.batch.begin();
        game.batch.draw(backgrounImg, background.x, background.y, background.width, background.height);
        game.font.draw(game.batch, "SCORE: " + score,40,430 );
        game.font.draw(game.batch, "PLANE HEALTH:" + input.health, 40,410);
        game.batch.draw(planeImg,plane.x,plane.y,plane.width,plane.height);
        game.batch.draw(leftLaserImg, leftNeon.x, leftNeon.y, leftNeon.width,leftNeon.height);
        game.batch.draw(rightLaserImg, rightNeon.x, rightNeon.y, rightNeon.width, rightNeon.height);
        if(Gdx.input.isKeyJustPressed(Input.Keys.SPACE)) {
            createPeluru();
            Rectangle y= peluruPlane.get(index);
            if(peluruPlane.get(index).intersects(meteor)){
                obstacle.setStrength(obstacle.getStrength()-50);
                if(obstacle.getStrength()<=0){
                    meteorDestroyedSound.play();
                    meteor.y=-50;
                    if(obstacle instanceof WeakMeteor){
					score+=50;
                    }else if(obstacle instanceof StrongMeteor){
        			score+=100;
                    }
                }
            }else {
                laserSound.play();
            }
            index++;
            game.batch.draw(peluruPlaneImg, y.x, y.y, y.width, y.height);

        }
        for (Rectangle blue: blueNeon){
            game.batch.draw(blueNeonImg, blue.x,blue.y, blue.width, blue.height);
        }
        if(randomMeteor==0) {
            game.batch.draw(meteorImg, meteor.x, meteor.y, meteor.width, meteor.height);
        }else if(randomMeteor==1){
           game.batch.draw(meteor2Img, meteor.x, meteor.y, meteor.width,meteor.height);
        }
        game.batch.end();

        if(Gdx.input.isKeyPressed(Input.Keys.LEFT)){
            input.left();
        }

        if(Gdx.input.isKeyPressed(Input.Keys.RIGHT)){
            input.right();
        }

        if(plane.x<=35){
            plane.x=35;
            collisionWithLaserSound.play();
            score--;
            input.health--;
        }
        if(plane.x >=510){
            plane.x=510;
            collisionWithLaserSound.play();
            score--;
            input.health--;
        }

        if(TimeUtils.nanoTime() - lastTime > 1999999999){
            randomMeteor= MathUtils.random(0,1);
            spawnBlueNeonAndMeteor();
            if(randomMeteor==0){
                obstacle= new StrongMeteor(meteor);
            }else {
                obstacle= new WeakMeteor(meteor);
            }
        }

        blueNeon.get(0).y-=250 * Gdx.graphics.getDeltaTime();
        blueNeon.get(1).y-=250 * Gdx.graphics.getDeltaTime();
        meteor.y-=250*Gdx.graphics.getDeltaTime();


        if(blueNeon.get(0).intersects(plane) || blueNeon.get(1).intersects(plane)){
            collisionWithLaserSound.play();
            score--;
            input.health--;
        }

        if(plane.intersects(meteor)){
            planeMeteor.play();
            score--;
            input.health--;
        }

        if(input.health<=0){
            TryAgainScreen againScreen = new TryAgainScreen(game,score);
            game.setScreen(againScreen);
        }

        if(score<=0){
            score=0;
        }
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        leftLaserImg.dispose();
        planeImg.dispose();
        rightLaserImg.dispose();
        peluruPlaneImg.dispose();
        blueNeonImg.dispose();
        meteorImg.dispose();
        meteor2Img.dispose();
        backgrounImg.dispose();
        planeMusic.dispose();
        laserSound.dispose();
        meteorDestroyedSound.dispose();
        collisionWithLaserSound.dispose();
        planeMeteor.dispose();

    }

    public void createPeluru(){
        Rectangle temp= new Rectangle();
        temp.x= plane.x + 25;
        temp.y=80;
        temp.width=5;
        temp.height=200;
        peluruPlane.add(temp);
    }

    public void spawnBlueNeonAndMeteor(){
        Rectangle left=new Rectangle();
        Rectangle right= new Rectangle();
        Rectangle meteor= new Rectangle();
        left.x=  0;
        left.y=500;
        left.width=MathUtils.random(100,450);
        left.height=20;

        right.x=left.x+ left.width+100;
        right.y=500;
        right.width=600-right.x;
        right.height=20;
        blueNeon.set(0,left);
        blueNeon.set(1,right);

        meteor.x=left.x+left.width+30;
        meteor.y=495;
        meteor.width=40;
        meteor.height=40;
        this.meteor=meteor;
        lastTime= TimeUtils.nanoTime();
    }



}
