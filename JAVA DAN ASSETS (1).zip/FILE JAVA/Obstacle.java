package com.mygdx.game;

import java.awt.*;

public class Obstacle {
    private Rectangle obstacle;
    private int strength;

    public Obstacle(){

    }

    public Obstacle(Rectangle input, int strength){
        setObstacle(input);
        setStrength(strength);
    }

    public Rectangle getObstacle() {
        return obstacle;
    }

    public void setObstacle(Rectangle obstacle) {
        this.obstacle = obstacle;
    }

    public int getStrength() {
        return strength;
    }

    public void setStrength(int strength) {
        this.strength = strength;
    }
}
