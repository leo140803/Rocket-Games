package com.mygdx.game;

import com.badlogic.gdx.Gdx;

import java.awt.*;

public class Plane implements interfacePlane {
    private Rectangle plane;
    int health;

    public Plane(Rectangle x, int health){
        setPlane(x);
        this.health=health;
    }
    @Override
    public void left() {
        getPlane().x-= 200 * Gdx.graphics.getDeltaTime();
    }

    @Override
    public void right() {
        getPlane().x+= 200 * Gdx.graphics.getDeltaTime();
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public int getHealth() {
        return health;
    }

    public void setPlane(Rectangle plane) {
        this.plane = plane;
    }

    public Rectangle getPlane() {
        return plane;
    }


}

interface interfacePlane{
    void left();
    void right();
}

