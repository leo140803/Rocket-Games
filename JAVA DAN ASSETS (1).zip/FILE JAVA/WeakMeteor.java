package com.mygdx.game;

import java.awt.*;

public class WeakMeteor extends Obstacle {

    public WeakMeteor(Rectangle input){
        super(input,50);
    }
}
