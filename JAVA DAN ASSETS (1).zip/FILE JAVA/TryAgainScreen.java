package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.utils.ScreenUtils;


public class TryAgainScreen implements Screen {
    Texture againTexture;
    final Meteor game;
    OrthographicCamera camera;
    GameScreen game2;
    int score;



    public TryAgainScreen(Meteor meteor, int Score) {
        game=meteor;
        againTexture= new Texture(Gdx.files.internal("gameOver.png"));
        camera=new OrthographicCamera();
        camera.setToOrtho(false,600,450);
        this.score=Score;
    }

    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0,0,0,1);
        camera.update();
        game.batch.setProjectionMatrix(camera.combined);
        game.batch.begin();

        game.batch.draw(againTexture,0,0,600,450);
        game.font.draw(game.batch, "SCORE: " + score, 210,200);
        game.batch.end();

        if(Gdx.input.isTouched()){
            game2= new GameScreen(game);
            game.setScreen(game2);
            dispose();
        }
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
